package bitcamp.ba.twentyfifth.medina;

public class Factorial {

	public static void main(String[] args) {
		int n = 34;
		int counter = 1;
		int factorial = 1;

		while (counter <= n) {
			factorial *= counter;
			counter++;
		}

		System.out.println("Factorial of " + n + " is " + factorial + ".");
	}

}
