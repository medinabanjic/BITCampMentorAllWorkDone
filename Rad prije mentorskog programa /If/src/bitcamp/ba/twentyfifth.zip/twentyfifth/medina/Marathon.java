package bitcamp.ba.twentyfifth.medina;

public class Marathon {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//long duration= System.current.millis();
		int meters= 41150;
		int metersRun= 0;
		int numIterations= 0;
		int a=0;
		
		
		do{
			metersRun+= Math.random();
			if (a > metersRun / 1000)
			{
				a++;
				System.out.println(".");
			}
			numIterations++;
						
		} while (metersRun < meters);
		
		
		System.out.println("Finish");
		System.out.println(numIterations);

	}

}
