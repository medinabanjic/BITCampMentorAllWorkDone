package bitcamp.ba.twentyfifth.medina;

public class Sums {

	public static void main(String[] args) {

		int n = -2;
		int counter = 1;
		int result = 0;

		if (n > 0) {
			while (counter <= n) {

				result += counter;
				counter++;
			}

			System.out.println(result);
		}else{
			System.out.println("Input positive number bigger than 0.");
		}
	}

}
