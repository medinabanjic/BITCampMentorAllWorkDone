package bitcamp.ba.twentyfifth.medina;

public class Length {

	public static void main(String[] args) {
		int n = 100;

		int counter = 0;

		int num = 0;

		while (n != 0) {

			num = n / 10;
			n = num;
			counter++;
		}

		System.out.println(counter);

	}

}
