package bitcamp.ba.twentyfifth.medina;

public class counter {

	public static void main(String[] args) {
		int counter= 8;
		int counterF=1;
		int a= 2;
				
		while (a>0){
		while (counter >= 2) {

			counterF = counterF * 10;
			counter--;
		}
		a--;		
		System.out.println(counterF);
		counterF= counterF / 10;
	}
}
	

}
