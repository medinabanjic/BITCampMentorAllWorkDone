package bitcamp.ba.twentyfifth.medina;

import java.util.Scanner;

public class Guess {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int maxNum= 100;
		int imagNum= (int)(Math.random() * maxNum);
		
		int trying, numTrying= 0;
		Scanner Ulaz= new Scanner (System.in);
		System.out.println("Input number: ");
		
		do{		
			
			numTrying++;
			
			trying= Ulaz.nextInt();
			if (trying > imagNum){
				System.out.print("Input lower number:");
			
			}
			else if (trying < imagNum){
				System.out.print("Input greater"
						+ " number:");
			
			}
			
			
		}while (trying != imagNum);
		
		System.out.println("\nYou guessed the number " + imagNum + " in " + numTrying + " tryings." );

	}}
