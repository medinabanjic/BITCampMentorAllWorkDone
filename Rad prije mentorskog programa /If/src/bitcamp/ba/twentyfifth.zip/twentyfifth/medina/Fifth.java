package bitcamp.ba.twentyfifth.medina;

public class Fifth {

	public static void main(String[] args) {
		int n = 1000;
		int counter = 1;

		while (counter <= n) {
			if (counter % 3 == 0 && counter % 2 != 0 && counter % 5 != 0) {
				System.out.println(+counter);
				
			}counter++;
			
		}

	}

}
