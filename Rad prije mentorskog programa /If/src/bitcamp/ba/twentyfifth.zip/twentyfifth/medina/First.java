package bitcamp.ba.twentyfifth.medina;

public class First {

	public static void main(String[] args) {
		int n= 45;
		int number= 0;

		while (number < n){
			
			System.out.println("*" + number);
			number++;
		}
	}

}
