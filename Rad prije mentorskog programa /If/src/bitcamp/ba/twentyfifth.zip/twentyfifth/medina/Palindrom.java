package bitcamp.ba.twentyfifth.medina;

public class Palindrom {

	public static void main(String[] args) {
		int n = 1;
		int digit = 0;
		int invertNum = 0;
		int counter = 1;
		int saveN= n;

		while (n > 0) {

			digit = n % 10;
			n = n / 10;
			invertNum += (digit * counter);
			counter = counter * 10;

		}
		
		
		System.out.println(invertNum);

		if (saveN == invertNum) {
			System.out.println("The number is a palindrome.");
		}

		else {
			System.out.println("The number is not a palindrome.");
		}

	}

}
