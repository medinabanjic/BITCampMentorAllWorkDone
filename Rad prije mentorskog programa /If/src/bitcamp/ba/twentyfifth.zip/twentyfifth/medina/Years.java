package bitcamp.ba.twentyfifth.medina;

public class Years {

	public static void main(String[] args) {

		int dayBirth = 10;
		int monthBirth = 12;
		int yearBirth = 1993;
		int counter = 1;
		int dayNow = 25;
		int monthNow = 5;
		int yearNow = 2015;

		int years = 1;

		while (yearBirth + counter <= yearNow) {

			years = counter;
			counter++;

			if (monthBirth > monthNow) {

				years -= 1;
			}

			if (dayBirth > dayNow && monthBirth == monthNow) {

				years -= 1;

			}

			System.out.println(dayBirth + "." + monthBirth + "."
					+ (yearBirth + years));
		}

	}

}
