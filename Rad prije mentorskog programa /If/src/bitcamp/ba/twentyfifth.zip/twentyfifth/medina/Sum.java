package bitcamp.ba.twentyfifth.medina;

public class Sum {

	public static void main(String[] args) {
		

		int numbers= 100;
		int sum= 0;
		int num= 1;
		
		do {
			sum += num;
			num++;
			}
		while (num <= numbers);
		
		System.out.println(sum);
	}

}
